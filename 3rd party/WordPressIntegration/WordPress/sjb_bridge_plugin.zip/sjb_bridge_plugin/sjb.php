<?php
/*
Plugin Name: SJB
Plugin URI: http://smartjobboard.com/
Description: 
Version:4.0
Author: SJB
Author URI: http://smartjobboard.com/
*/

define('SJB_VERSION', '3.0');
$ds = DIRECTORY_SEPARATOR;
define( 'SJB_PATH_BASE', dirname(__FILE__ )."{$ds}..{$ds}..{$ds}..{$ds}..");
add_filter('authenticate', 'sjbLogin', 40, 3);
add_action('wp_logout','sjbLogout');

function sjbLogin($user, $username, $password) {
	$noSJB = !empty($_REQUEST['noSJB'])?$_REQUEST['noSJB']:false;
	$userInfo = !empty($_REQUEST['userInfo'])?$_REQUEST['userInfo']:false;
	$userdata = get_userdatabylogin($username);
	if ($username !== '' && $password !== '' && !$noSJB) {
		$dir = getcwd();
		loadSJBToWP();
		//get the sjb user
		$SJB_errors = array();
		$logged_in = SJB_Authorization::login($username, $password, false, $SJB_errors, false);
		
		// user not in wordpress db, but is in sjb
		$userInfo = SJB_UserDBManager::getUserInfoByUserName($username); 
		chdir($dir);
		if ($userdata && $userInfo && !isset($SJB_errors['USER_NOT_ACTIVE']) && !isset($SJB_errors['BANNED_USER'])) {
			if (!$logged_in && !is_wp_error($user)) {
				if (SJB_UserManager::changeUserPassword($userInfo['sid'], $password)){
					$SJB_errors = array();
					$logged_in = SJB_Authorization::login($username, $password, false, $SJB_errors, false);
				}
			}
			elseif ($logged_in && is_wp_error($user)) {
				if (  in_array('incorrect_password', $user->get_error_codes()) ) {
					require_once( ABSPATH . WPINC . '/registration.php');
					loadWordPress();
					$userdata->user_pass = $password;
					$user_id = wp_update_user( get_object_vars( $userdata ));
					$user = get_userdatabylogin($username);
				}
			}
		}
		elseif ($logged_in && $userInfo && !$userdata) {
			require_once( ABSPATH . WPINC . '/registration.php');
			loadWordPress();
			$user_id = wp_create_user( $username, $password, $userInfo['email'] );
			//$user = get_userdatabylogin($username);
			$user = new WP_User($user_id);
		}
		else {
			if (isset($SJB_errors['INVALID_PASSWORD'])) {
				return new WP_Error('incorrect_password', sprintf(__('<strong>ERROR</strong>: Incorrect password. <a href="%s" title="Password Lost and Found">Lost your password</a>?'), site_url('wp-login.php?action=lostpassword', 'login')));
			}
			elseif (isset($SJB_errors['USER_NOT_ACTIVE'])){
				return new WP_Error('user_not_active', sprintf(__('<strong>ERROR</strong>: Your account is not active.', 'login')));
			}
			elseif (isset($SJB_errors['BANNED_USER'])) {
				return new WP_Error('banned_user', sprintf(__('<strong>ERROR</strong>: You IP address has been banned by site administrator.', 'login')));
			}
		}
	}
	elseif ($noSJB && $userInfo && !$userdata) {
		$userInfo = unserialize(base64_decode($userInfo));
		require_once( ABSPATH . WPINC . '/registration.php');
		$user_id = wp_create_user( $username, $password, $userInfo['email'] );
		//$user = get_userdatabylogin($username);
		$user = new WP_User($user_id);
	}
	return $user;
}

function sjbLogout(){
	$noSJB = !empty($_REQUEST['noSJB'])?$_REQUEST['noSJB']:false;
	if (!$noSJB) {
		$dir = getcwd();
		loadSJBToWP();
		SJB_Authorization::logout();
		chdir($dir);
	}
}

function loadSJBToWP()
{
	// System includes
	define ('SJB_BASE_DIR', SJB_PATH_BASE."/");
	require_once(SJB_PATH_BASE.'/system/core/System.php');
	SJB_System::loadSystemSettings (SJB_PATH_BASE.'/config.php');
	SJB_System::loadSystemSettings (SJB_PATH_BASE.'/system/user-config/DefaultSettings.php');
	SJB_System::boot();
	SJB_DB :: init(SJB_System::getSystemSettings('DBHOST'), SJB_System::getSystemSettings('DBUSER'), SJB_System::getSystemSettings('DBPASSWORD'), SJB_System::getSystemSettings('DBNAME'));
	SJB_Session::init(SJB_System::getSystemSettings('SITE_URL'));
}

function loadWordPress() {
	global $wpdb, $table_prefix;
	$wpdb = new wpdb(DB_USER, DB_PASSWORD, DB_NAME, DB_HOST);
	$prefix = $wpdb->set_prefix($table_prefix);
}